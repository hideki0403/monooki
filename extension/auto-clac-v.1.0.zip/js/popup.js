$('.picker').datepicker({
    format: 'yyyy-mm-dd',
    language:'ja'
})

sbj = []

function dataFormat() {
    for(i = 0; 6 > i; i++) {
        sbj.push($('#sbj-' + i + '-h').val() + ':' + $('#sbj-' + i + '-m').val())
    }
}

$(document).ready(function() {
    var d = JSON.parse(localStorage.getItem('data'))

    if(d) {
        $('#date-start').val(d.date.start)
        $('#date-end').val(d.date.end)
        for(i = 0; 6 > i; i++) {
            tmpD = d.subject[i].split(':')
            $('#sbj-' + i + '-h').val(tmpD[0])
            $('#sbj-' + i + '-m').val(tmpD[1])
        }
    }
})

$('#start').on('click', function() {
    dataFormat()
    var data = {
        date: {
            start: $('#date-start').val(),
            end: $('#date-end').val()
        },
        subject: sbj
    }

    if($('#date-start').val() === '' || $('#date-end').val() === '') {
        $('#message').text('開始日、または終了日を入力してください。')
    } else {
        localStorage.data = JSON.stringify(data)
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {contents: 'run', data: data}, function (response) {
                console.log(response)
            })
        })
    }
})

$('#stop').on('click', function() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {contents: 'stop'}, function (response) {
            console.log(response)
        })
    })
})