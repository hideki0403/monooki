function timeReplace(t) {
    return ('0' + t).slice(-2)
}

function run(data) {
    isStoped = false
    location.href = 'https://study.classi.jp/#/reports/form/' + data.date.start
    whileFunc(data)
}

function whileFunc(data) {
    try{
        if(isStoped) {
            // 何らかの形で停止させたくなったとき用
            alert('停止されました。')
        } else {
// 読み込みがあるため1500ms(1.5s)待機
setTimeout(function() {
    path = location.hash
    console.log(path)
    if(path.match(/daily/)) {
        // dailyページだった場合
        var date = path.replace('#/reports/daily/', '')
        if(date === data.date.end) {
            // もし終了日時と合致していた場合はwhileから抜ける
            alert('すべての処理に成功しました。')
        } else {
            // 翌日の日付を求めてページを移動する
            var dateS = new Date(date)
            dateS.setDate(dateS.getDate() + 1)
            location.href = 'https://study.classi.jp/#/reports/form/' + dateS.getFullYear() + '-' + ('0' + (dateS.getMonth() + 1)).slice(-2) + '-' + ('0' + dateS.getDate()).slice(-2)
            whileFunc(data)
        }
    } else {
        // dailyページではなかった場合 (=form)
        for(i = 0; data.subject.length > i; i++) {
            // 時間入力を行う
            var tmp = data.subject[i].split(':')
            var hour = tmp[0]
            var minute = tmp[1]
            $('[ng-click="minuteChange(\'' + minute + '\',\'' + timeReplace(minute) + '\');"]')[5 + i].click()
            $('[ng-click="hourChange(\'' + hour + '\',\'' + timeReplace(hour) + '\')"]')[5 + i].click()
        }
        // 完了したら確定ボタンをクリック
        setTimeout(function() {
            $('[ng-click="update()"]').click()
            whileFunc(data)
        }, 500)
    }
}, 4000)
        }
    } catch(err) {
        console.log("エラーが発生しました")
        console.log(error.name)
        console.log(error.message)
    }
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.contents === 'run') {
        run(request.data)
    } else {
        if(request.contents === 'stop') {
            isStoped = true
        }
    }
})

/* データ送受信用の雛形
data = {
    date: {
        start: '2019-08-15',
        end: '2019-08-31'
    },
    subject: ['0:20', '0:40', '0:30', '0:0', '0:0', '0:0']
}
*/

/* ----- Subjectについて -----
Arrayで先頭から順に
5 : 国
6 : 数
7 : 英
8 : 理
9 : 社
10: スマホ・タブ
を割り当てる。
空白は0分扱い。
---------------------------- */